#!/bin/bash

TOPDIR=`pwd`
MYPROJECT="$TOPDIR/submitted"
MYEXE="./duplicates"

if [ ! -d $MYPROJECT ]; then
    echo "cannot find the '$MYPROJECT' directory"
    echo "run   mkdir '$MYPROJECT'  and then"
    echo "copy your Makefile, *.c, and *.h file(s) into the '$MYPROJECT' directory"
    exit 1
fi
if [ ! -f $MYPROJECT/Makefile ]; then
    echo "cannot find a Makefile in your '$MYPROJECT' directory"
    echo "copy your Makefile, *.c, and *.h file(s) into the '$MYPROJECT' directory"
    exit 1
fi

# --------------------------------------------------------------

SAMPLEDIR="$TOPDIR/SAMPLE"
BASIC="$SAMPLEDIR/soln/duplicates-basic"
ADVANCED="$SAMPLEDIR/soln/duplicates-advanced"
SCRIPTDIR="$TOPDIR/TESTSCRIPTS"
#
RUNDIR="/tmp/RUN"
TESTDIR="testdirectory"
#
RUN4="$SAMPLEDIR/run4"
export RUN4_EXITSTATUS="/tmp/run4-exitstatus"
export RUN4_TIMEOUT="10sec"
#
CSTD="c11"
#
make -C $SAMPLEDIR/soln clean
make -C $SAMPLEDIR/soln                             	|| exit 1
cc -std=$CSTD -Wall -Werror -o $RUN4   $RUN4.c		|| exit 1

# --------------------------------------------------------------

if [ -t 1 ]; then
    RED="\033[1;31m" ; BLUE="\033[1;34m" ; OFF="\033[0m"
else
    RED="" ; BLUE="" ; OFF=""
fi

function red {
    echo -e "${RED}$1${OFF}"
}

function blue {
    echo -e "${BLUE}$1${OFF}"
}

function dump_output {
    if [ -f $1 ]; then
	echo $2
	sed  's/^/    /' < $1
    fi
}

function dump_outputs {
# uncomment the following line for less verbose output
#return
    dump_output output0 "--- sample solution's (possibly modified) output: ---"
    dump_output output1 "--- your solution's (possibly modified) output: ---"
    echo "exit-status of your solution: $ss"
}

function getSTATS1234 {
    grep '[0-9]' < $1 | tr -dc '0-9\n' > .tmp
    N1=`sed -n '1p' < .tmp`	# total number of files found
    N2=`sed -n '2p' < .tmp`	# total size (bytes) of files found
    N3=`sed -n '3p' < .tmp`	# total number of unique files found
    N4=`sed -n '4p' < .tmp`	# possible minimum size (bytes) of files found
    rm -f .tmp
    echo "$N1-$N2-$N3-$N4"
}

function getSTATS134 {
    grep '[0-9]' < $1 | tr -dc '0-9\n' > .tmp
    N1=`sed -n '1p' < .tmp`	# total number of files found
    N2=`sed -n '2p' < .tmp`	# total size (bytes) of files found
    N3=`sed -n '3p' < .tmp`	# total number of unique files found
    N4=`sed -n '4p' < .tmp`	# possible minimum size (bytes) of files found
    rm -f .tmp
    echo "$N1-$N3-$N4"
}

function addmark {
    MYMARK=`expr $MYMARK + $2`
    TOTALMARK=`expr $TOTALMARK + $3`
    blue "$1 - $2/$3 - $OUTCOME - $DESC"
    echo
}

# --------------------------------------------------------------

function preclean {
#    echo -e "${OFF}"
    MARK="0"
    OUTCOME="Unsuccessful"
    rm -rf SO SE output? $RUN4_EXITSTATUS $TESTDIR .tmp
    echo running ${FUNCNAME[1]}
}

function finalclean {
#    echo -e "${OFF}"
    make -C $SAMPLEDIR/soln clean
    rm -rf SO SE output? $RUNDIR $RUN4_EXITSTATUS $TESTDIR .tmp
}

# --------------------------------------------------------------

function test_0 {
    preclean
    DESC="project compiled without warnings or errors"

    (make > SO) &> SE
    if [ "$?" != "0" ]; then
	red "compile failed"
	cat < SE
	MARK="0"
	OUTCOME="Project did not compile."
	DESC="Unable to test project with automated tests."
	addmark ${FUNCNAME[0]} $MARK $1
	MYMARK="DNC"
    else
	if [ ! -x $MYEXE ]; then
	    red "running 'make' does not produce $MYEXE"
	    exit 1
	fi
	MARK="$1"
	OUTCOME="Successful"
	addmark ${FUNCNAME[0]} $MARK $1
    fi
}

# --------------------------------------------------------------

function test_1 {
    preclean
    DESC="detects invalid option, prints message, exits with failure"

    $RUN4 $MYEXE -Z /tmp	&> output1
    ss=`cat $RUN4_EXITSTATUS`
    if [ "$ss" = "59" ]; then
	OUTCOME="TIMEOUT (after $RUN4_TIMEOUT)"
    else
	if [ "$ss" != "0" ]; then
	    MARK=`expr $MARK + 1`
	fi
	if [ -s output1 ]; then
	    MARK=`expr $MARK + 1`
	fi
	if [ "$MARK" = "$1" ]; then
	    OUTCOME="Successful"
	fi
    fi
    dump_outputs
    addmark ${FUNCNAME[0]} $MARK $1
}

# --------------------------------------------------------------

function test_2 {
    preclean
    DESC="detects a non-existent directory, prints message, exits with failure"

    $RUN4 $MYEXE DIR_DNE	&> output1
    ss=`cat $RUN4_EXITSTATUS`
    if [ "$ss" = "59" ]; then
	OUTCOME="TIMEOUT (after $RUN4_TIMEOUT)"
    else
	if [ "$ss" != "0" ]; then
	    MARK=`expr $MARK + 1`
	fi
	if [ -s output1 ]; then
	    MARK=`expr $MARK + 1`
	fi
	if [ "$MARK" = "$1" ]; then
	    OUTCOME="Successful"
	fi
    fi
    dump_outputs
    addmark ${FUNCNAME[0]} $MARK $1
}

# --------------------------------------------------------------

function test_3 {
    preclean
    DESC="counting files and sizes (no duplicates)"
    source $SCRIPTDIR/ts3	; tester
#
    $RUN4 $MYEXE $TESTDIR	&> output1
    ss=`cat $RUN4_EXITSTATUS`
    if [ "$ss" = "59" ]; then
	OUTCOME="TIMEOUT (after $RUN4_TIMEOUT)"
    elif [ -s output1 ]; then
	$BASIC $TESTDIR		&> output0
	NN0=`getSTATS1234 output0`
	NN1=`getSTATS1234 output1`
	if [ "$NN0" = "$NN1" ]; then
	    MARK="$1"
	    OUTCOME="Successful"
	fi
    fi
    dump_outputs
    addmark ${FUNCNAME[0]} $MARK $1
}

# --------------------------------------------------------------

function test_4 {
    preclean
    DESC="counting files and sizes (no duplicates), descends into subdirectories"
    source $SCRIPTDIR/ts4	; tester
#
    $RUN4 $MYEXE $TESTDIR	&> output1
    ss=`cat $RUN4_EXITSTATUS`
    if [ "$ss" = "59" ]; then
	OUTCOME="TIMEOUT (after $RUN4_TIMEOUT)"
    elif [ -s output1 ]; then
	$BASIC $TESTDIR		&> output0
	NN0=`getSTATS1234 output0`
	NN1=`getSTATS1234 output1`
	if [ "$NN0" = "$NN1" ]; then
	    MARK="$1"
	    OUTCOME="Successful"
	fi
    fi
    dump_outputs
    addmark ${FUNCNAME[0]} $MARK $1
}

# --------------------------------------------------------------

function test_5 {
    preclean
    DESC="counting files and sizes (with duplicates)"
    source $SCRIPTDIR/ts5	; tester
#
    $RUN4 $MYEXE $TESTDIR	&> output1
    ss=`cat $RUN4_EXITSTATUS`
    if [ "$ss" = "59" ]; then
	OUTCOME="TIMEOUT (after $RUN4_TIMEOUT)"
    elif [ -s output1 ]; then
	$BASIC $TESTDIR		&> output0
	NN0=`getSTATS1234 output0`
	NN1=`getSTATS1234 output1`
	if [ "$NN0" = "$NN1" ]; then
	    MARK="$1"
	    OUTCOME="Successful"
	fi
    fi
    dump_outputs
    addmark ${FUNCNAME[0]} $MARK $1
}

# --------------------------------------------------------------

function test_6 {
    preclean
    DESC="support for -a command-line option"
    source $SCRIPTDIR/ts6	; tester
#
    $RUN4 $MYEXE -a $TESTDIR	&> output1
    ss=`cat $RUN4_EXITSTATUS`
    if [ "$ss" = "59" ]; then
	OUTCOME="TIMEOUT (after $RUN4_TIMEOUT)"
    elif [ -s output1 ]; then
	$BASIC -a $TESTDIR	&> output0
	NN0=`getSTATS1234 output0`
	NN1=`getSTATS1234 output1`
	if [ "$NN0" = "$NN1" ]; then
	    MARK="$1"
	    OUTCOME="Successful"
	fi
    fi
    dump_outputs
    addmark ${FUNCNAME[0]} $MARK $1
}

# --------------------------------------------------------------

function test_7 {
    preclean
    DESC="support for -f command-line option"
    F="/bin/ls"
    source $SCRIPTDIR/ts7	; tester $F
#
    $RUN4 $MYEXE -f $F $TESTDIR		2>&1 | \
	tr -cs A-Za-z '\n' | grep -v '^$' | grep -v $TESTDIR | sort > output1
    ss=`cat $RUN4_EXITSTATUS`
    if [ "$ss" = "59" ]; then
	OUTCOME="TIMEOUT (after $RUN4_TIMEOUT)"
    elif [ -s output1 ]; then
	$BASIC -f $F $TESTDIR		2>&1 | \
	tr -cs A-Za-z '\n' | grep -v '^$' | grep -v $TESTDIR | sort > output0
	if cmp -s output0 output1
	then
	    MARK="$1"
	    OUTCOME="Successful"
	fi
    fi
    dump_outputs
    addmark ${FUNCNAME[0]} $MARK $1
}

# --------------------------------------------------------------

function test_8 {
    preclean
    DESC="support for -h command-line option"
    F="/bin/ls"
    H=`shasum -a 256 $F | cut '-d ' -f1`
    source $SCRIPTDIR/ts8	; tester $F
#
    $RUN4 $MYEXE -h $H $TESTDIR		2>&1 | \
	tr -cs A-Za-z '\n' | grep -v '^$' | grep -v $TESTDIR | sort > output1
    ss=`cat $RUN4_EXITSTATUS`
    if [ "$ss" = "59" ]; then
	OUTCOME="TIMEOUT (after $RUN4_TIMEOUT)"
    elif [ -s output1 ]; then
	$BASIC -h $H $TESTDIR		2>&1 | \
	tr -cs A-Za-z '\n' | grep -v '^$' | grep -v $TESTDIR | sort > output0
	if cmp -s output0 output1
	then
	    MARK="$1"
	    OUTCOME="Successful"
	fi
    fi
    dump_outputs
    addmark ${FUNCNAME[0]} $MARK $1
}

# --------------------------------------------------------------

function test_9 {
    preclean
    DESC="support for -l command-line option"
    source $SCRIPTDIR/ts9	; tester
#
    $RUN4 $MYEXE -l $TESTDIR		2>&1 | \
	tr -cs A-Za-z '\n' | grep -v '^$' | grep -v $TESTDIR | sort > output1
    ss=`cat $RUN4_EXITSTATUS`
    if [ "$ss" = "59" ]; then
	OUTCOME="TIMEOUT (after $RUN4_TIMEOUT)"
    elif [ -s output1 ]; then
	$BASIC -l $TESTDIR		2>&1 | \
	tr -cs A-Za-z '\n' | grep -v '^$' | grep -v $TESTDIR | sort > output0
	if cmp -s output0 output1
	then
	    MARK="$1"
	    OUTCOME="Successful"
	fi
    fi
    dump_outputs
    addmark ${FUNCNAME[0]} $MARK $1
}

# --------------------------------------------------------------

function test_10 {
    preclean
    DESC="support for -q command-line option"
#
    source $SCRIPTDIR/ts10a	; tester
    $RUN4 $MYEXE -q $TESTDIR		>& /dev/null
    ss=`cat $RUN4_EXITSTATUS`
    if [ "$ss" = "59" ]; then
	OUTCOME="TIMEOUT (after $RUN4_TIMEOUT)"
    elif [ "$ss" = "0" ]; then
	MARK=`expr $MARK + 1`
    fi
#
    source $SCRIPTDIR/ts10b	; tester
    $RUN4 $MYEXE -q $TESTDIR		>& /dev/null
    ss=`cat $RUN4_EXITSTATUS`
    if [ "$ss" = "59" ]; then
	OUTCOME="TIMEOUT (after $RUN4_TIMEOUT)"
    elif [ "$ss" != "0" ]; then
	MARK=`expr $MARK + 1`
    fi
#
    if [ "$MARK" = "$1" ]; then
	OUTCOME="Successful"
    fi

    dump_outputs
    addmark ${FUNCNAME[0]} $MARK $1
}

# --------------------------------------------------------------

function test_ADV1 {
    preclean
    DESC="(ADVANCED) counting duplicate files from multiple directories"
    source $SCRIPTDIR/tsADV1	; tester
#
    $RUN4 $MYEXE $TESTDIR-A $TESTDIR-B $TESTDIR-C	&> output1
    ss=`cat $RUN4_EXITSTATUS`
    if [ "$ss" = "59" ]; then
	OUTCOME="TIMEOUT (after $RUN4_TIMEOUT)"
    elif [ -s output1 ]; then
	$ADVANCED $TESTDIR-A $TESTDIR-B $TESTDIR-C	&> output0
	NN0=`getSTATS134 output0`
	NN1=`getSTATS134 output1`
	if [ "$NN0" = "$NN1" ]; then
	    MARK="$1"
	    OUTCOME="Successful"
	fi
    fi
    dump_outputs
    addmark ${FUNCNAME[0]} $MARK $1
}

# --------------------------------------------------------------

function test_ADV2 {
    preclean
    DESC="(ADVANCED) detecting hard-linked files, contents only counted once"
    source $SCRIPTDIR/tsADV2	; tester
#
    $RUN4 $MYEXE $TESTDIR	&> output1
    ss=`cat $RUN4_EXITSTATUS`
    if [ "$ss" = "59" ]; then
	OUTCOME="TIMEOUT (after $RUN4_TIMEOUT)"
    elif [ -s output1 ]; then
	$ADVANCED $TESTDIR	&> output0
	NN0=`getSTATS134 output0`
	NN1=`getSTATS134 output1`
	if [ "$NN0" = "$NN1" ]; then
	    MARK="$1"
	    OUTCOME="Successful"
	fi
    fi
    dump_outputs
    addmark ${FUNCNAME[0]} $MARK $1
}

# --------------------------------------------------------------

function test_ADV3 {
    preclean
    DESC="(ADVANCED) support for -m command-line option"
    source $SCRIPTDIR/tsADV3	; tester
#
    $RUN4 $MYEXE -m $TESTDIR	&> output1
    ss=`cat $RUN4_EXITSTATUS`
    if [ "$ss" = "59" ]; then
	OUTCOME="TIMEOUT (after $RUN4_TIMEOUT)"
    elif [ -s output1 ]; then
	$ADVANCED -m $TESTDIR	&> output0
	NN0=`getSTATS134 output0`
	NN1=`getSTATS134 output1`
	if [ "$NN0" = "$NN1" ]; then
	    MARK="$1"
	    OUTCOME="Successful"
	fi
    fi
    dump_outputs
    addmark ${FUNCNAME[0]} $MARK $1
}

# --------------------------------------------------------------

#  COPY SUBMITTED FILES TO $RUNDIR,  APPEND newlines TO SOURCE FILES
function prepare_automated_tests {
    cp -pR $MYPROJECT/* .
    for f in *.[ch]
    do
	echo >> $f
    done
}

#  IN POPULATED $RUNDIR DIRECTORY WHEN CALLED
function run_automated_tests {
    AB="0"
    AX="0"
    MYMARK="0"
    TOTALMARK="0"

    echo
    red "RUNNING AUTOMATED TESTS OF BASIC VERSION"
    test_0 2

    if [ "$MYMARK" == "DNC" ] ; then
	red "compile failed"
	MYMARK="0"
	TOTALMARK="25"
	red "PROJECT DID NOT COMPILE. UNABLE TO TEST WITH AUTOMATED TESTS - $MYMARK / $TOTALMARK"
	return
    else
	test_1  2
	test_2  2
	test_3  2
	test_4  2
	test_5  2
	test_6  2
	test_7  3
	test_8  3
	test_9  3
	test_10 2
	AB="$MYMARK"
	red "AUTOMATED TESTS OF BASIC VERSION - $MYMARK / $TOTALMARK"

#  HAVE ATTEMPTED THE ADVANCED VERSION?
	if $MYEXE -A /tmp &> /dev/null
	then
	    echo
	    red "RUNNING AUTOMATED TESTS OF ADVANCED VERSION"
	    MYMARK="0"
	    TOTALMARK="0"
		test_ADV1 1
		test_ADV2 2
		test_ADV3 2
	    AX="$MYMARK"
	    red "AUTOMATED TESTS OF ADVANCED VERSION - $MYMARK / $TOTALMARK"
	else
	    red "ADVANCED VERSION NOT ATTEMPTED"
	fi
    fi
    MYMARK=`expr $AB + $AX`
    echo
    red "TOTAL MARK FROM AUTOMATED TESTS - $MYMARK"
}

# --------------------------------------------------------------

rm -rf $RUNDIR ; mkdir $RUNDIR ; cd $RUNDIR
prepare_automated_tests
run_automated_tests

finalclean
