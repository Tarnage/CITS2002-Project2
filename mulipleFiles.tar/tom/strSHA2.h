#ifndef STR_SHA2_H
#define STR_SHA2_H
// -----------------------------------------------------------------------------------------------
//  THESE FUNCTIONS ARE DECLARED HERE, AND DEFINED IN strSHA2.c :

// DECLARE GLOBAL FUNCTIONS
extern    char      *strSHA2(char *);
#endif
